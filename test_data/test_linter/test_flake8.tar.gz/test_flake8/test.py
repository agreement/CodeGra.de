def a(b):
	print ( 5 )
